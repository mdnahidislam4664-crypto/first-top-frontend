class VideoModel {
  final String id;
  final String videoUrl;
  final String thumbnailUrl;
  final String caption;
  final List<String> tags;
  final String userId;
  final String username;
  final String userAvatar;
  int likesCount;
  final int commentsCount;
  final int sharesCount;
  final bool isHighlighted;
  bool isLiked;

  VideoModel({
    required this.id,
    required this.videoUrl,
    required this.thumbnailUrl,
    required this.caption,
    required this.tags,
    required this.userId,
    required this.username,
    required this.userAvatar,
    required this.likesCount,
    required this.commentsCount,
    required this.sharesCount,
    required this.isHighlighted,
    this.isLiked = false,
  });

  factory VideoModel.fromJson(Map<String, dynamic> json) {
    final user = json['user'] is Map<String, dynamic> ? json['user'] : {};
    return VideoModel(
      id: json['_id'] ?? '',
      videoUrl: json['video_url'] ?? '',
      thumbnailUrl: json['thumbnail_url'] ?? '',
      caption: json['caption'] ?? '',
      tags: List<String>.from(json['tags'] ?? []),
      userId: user['_id'] ?? '',
      username: user['username'] ?? 'User',
      userAvatar: user['avatar'] ?? 'https://via.placeholder.com/150',
      likesCount: json['likes_count'] ?? 0,
      commentsCount: json['comments_count'] ?? 0,
      sharesCount: json['shares_count'] ?? 0,
      isHighlighted: json['is_highlighted'] ?? false,
    );
  }
}