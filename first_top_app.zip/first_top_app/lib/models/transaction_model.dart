class TransactionModel {
  final String id;
  final String type; // gift, deposit, withdrawal
  final double amount;
  final String status; // pending, completed, rejected
  final String paymentMethod;
  final String transactionId;
  final DateTime createdAt;

  TransactionModel({
    required this.id,
    required this.type,
    required this.amount,
    required this.status,
    required this.paymentMethod,
    required this.transactionId,
    required this.createdAt,
  });

  factory TransactionModel.fromJson(Map<String, dynamic> json) {
    return TransactionModel(
      id: json['_id'] ?? '',
      type: json['type'] ?? 'gift',
      amount: (json['amount'] ?? 0).toDouble(),
      status: json['status'] ?? 'pending',
      paymentMethod: json['payment_method'] ?? 'in_app',
      transactionId: json['transaction_id'] ?? '',
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt']).toLocal()
          : DateTime.now(),
    );
  }
}