class CommentModel {
  final String id;
  final String text;
  final String userId;
  final String username;
  final String userAvatar;
  bool isPinned;
  final DateTime createdAt;

  CommentModel({
    required this.id,
    required this.text,
    required this.userId,
    required this.username,
    required this.userAvatar,
    required this.isPinned,
    required this.createdAt,
  });

  factory CommentModel.fromJson(Map<String, dynamic> json) {
    final user = json['user'] is Map ? json['user'] : {};
    return CommentModel(
      id: json['_id'] ?? '',
      text: json['text'] ?? '',
      userId: user['_id'] ?? '',
      username: user['username'] ?? 'User',
      userAvatar: user['avatar'] ?? 'https://via.placeholder.com/150',
      isPinned: json['is_pinned'] ?? false,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt']).toLocal()
          : DateTime.now(),
    );
  }
}