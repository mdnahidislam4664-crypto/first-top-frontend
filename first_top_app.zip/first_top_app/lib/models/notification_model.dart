class NotificationModel {
  final String id;
  final String senderUsername;
  final String senderAvatar;
  final String type; // like, comment, follow, gift
  final String message;
  final bool isRead;
  final DateTime createdAt;

  NotificationModel({
    required this.id,
    required this.senderUsername,
    required this.senderAvatar,
    required this.type,
    required this.message,
    required this.isRead,
    required this.createdAt,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    final sender = json['sender'] is Map ? json['sender'] : {};
    return NotificationModel(
      id: json['_id'] ?? '',
      senderUsername: sender['username'] ?? 'User',
      senderAvatar: sender['avatar'] ?? 'https://via.placeholder.com/150',
      type: json['type'] ?? 'system',
      message: json['message'] ?? '',
      isRead: json['is_read'] ?? false,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt']).toLocal()
          : DateTime.now(),
    );
  }
}