class ChatMessageModel {
  final String id;
  final String senderId;
  final String receiverId;
  final String text;
  final String mediaUrl;
  int status; // 0 = Sent, 1 = Delivered, 2 = Seen
  final DateTime createdAt;

  ChatMessageModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.text,
    required this.mediaUrl,
    required this.status,
    required this.createdAt,
  });

  factory ChatMessageModel.fromJson(Map<String, dynamic> json) {
    return ChatMessageModel(
      id: json['_id'] ?? '',
      senderId: json['sender'] is Map ? json['sender']['_id'] : (json['sender'] ?? ''),
      receiverId: json['receiver'] is Map ? json['receiver']['_id'] : (json['receiver'] ?? ''),
      text: json['text'] ?? '',
      mediaUrl: json['media_url'] ?? '',
      status: json['status'] ?? 0,
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt']).toLocal()
          : DateTime.now(),
    );
  }
}