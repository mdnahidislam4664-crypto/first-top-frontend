import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'controllers/auth_controller.dart';
import 'controllers/video_controller.dart';
import 'controllers/upload_controller.dart';
import 'controllers/chat_controller.dart';
import 'controllers/wallet_controller.dart';
import 'controllers/monetization_controller.dart';
import 'controllers/theme_language_controller.dart'; // নতুন কন্ট্রোলার
import 'views/splash/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  WakelockPlus.enable(); // স্ক্রিন আলো অলওয়েজ অন

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthController()),
        ChangeNotifierProvider(create: (_) => VideoController()),
        ChangeNotifierProvider(create: (_) => UploadController()),
        ChangeNotifierProvider(create: (_) => ChatController()),
        ChangeNotifierProvider(create: (_) => WalletController()),
        ChangeNotifierProvider(create: (_) => MonetizationController()),
        ChangeNotifierProvider(create: (_) => ThemeLanguageController()), // প্যাকেজ ৩
      ],
      child: const FirstTopApp(),
    ),
  );
}

class FirstTopApp extends StatelessWidget {
  const FirstTopApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeCtrl = Provider.of<ThemeLanguageController>(context);

    return MaterialApp(
      title: 'First Top',
      debugShowCheckedModeBanner: false,
      themeMode: themeCtrl.isDarkMode ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const SplashScreen(),
    );
  }
}