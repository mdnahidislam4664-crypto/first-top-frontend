import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../controllers/chat_controller.dart';
import '../../models/chat_model.dart';

class ChatScreen extends StatefulWidget {
  final String receiverId;
  final String receiverUsername;
  final String receiverAvatar;
  final String myUserId;

  const ChatScreen({
    super.key,
    required this.receiverId,
    required this.receiverUsername,
    required this.receiverAvatar,
    required this.myUserId,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    final chatCtrl = Provider.of<ChatController>(context, listen: false);
    chatCtrl.connectSocket();
    chatCtrl.fetchChatHistory(widget.receiverId);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
      }
    });
  }

  // ৩-স্টেট রিড রিসিট আইকন
  Widget _buildReadReceipt(int status) {
    switch (status) {
      case 0:
        return const Icon(Icons.check, size: 15, color: Colors.grey); // Sent
      case 1:
        return const Icon(Icons.done_all, size: 15, color: Colors.grey); // Delivered
      case 2:
        return const Icon(Icons.done_all, size: 15, color: Colors.lightBlueAccent); // Seen
      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatCtrl = Provider.of<ChatController>(context);
    _scrollToBottom();

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        titleSpacing: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundImage: NetworkImage(widget.receiverAvatar),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '@${widget.receiverUsername}',
                  style: const TextStyle(fontSize: 16, color: Colors.white),
                ),
                Text(
                  chatCtrl.isReceiverTyping ? 'টাইপ করছেন...' : 'অনলাইন',
                  style: TextStyle(
                    fontSize: 12,
                    color: chatCtrl.isReceiverTyping ? Colors.greenAccent : Colors.grey,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: chatCtrl.isLoading
                ? const Center(child: CircularProgressIndicator(color: Colors.redAccent))
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    itemCount: chatCtrl.messages.length,
                    itemBuilder: (context, index) {
                      final msg = chatCtrl.messages[index];
                      final isMe = msg.senderId == widget.myUserId;

                      return Align(
                        alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width * 0.75,
                          ),
                          decoration: BoxDecoration(
                            color: isMe ? Colors.redAccent : Colors.grey[850],
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(16),
                              topRight: const Radius.circular(16),
                              bottomLeft: isMe ? const Radius.circular(16) : Radius.zero,
                              bottomRight: isMe ? Radius.zero : const Radius.circular(16),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment:
                                isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                            children: [
                              Text(
                                msg.text,
                                style: const TextStyle(color: Colors.white, fontSize: 15),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    DateFormat('hh:mm a').format(msg.createdAt),
                                    style: const TextStyle(color: Colors.white60, fontSize: 10),
                                  ),
                                  if (isMe) ...[
                                    const SizedBox(width: 4),
                                    _buildReadReceipt(msg.status),
                                  ],
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            color: Colors.grey[900],
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _msgController,
                    style: const TextStyle(color: Colors.white),
                    onChanged: (val) {
                      chatCtrl.sendTypingStatus(val.trim().isNotEmpty);
                    },
                    decoration: InputDecoration(
                      hintText: 'একটি বার্তা লিখুন...',
                      hintStyle: const TextStyle(color: Colors.grey),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.redAccent),
                  onPressed: () {
                    chatCtrl.sendMessage(_msgController.text);
                    chatCtrl.sendTypingStatus(false);
                    _msgController.clear();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}