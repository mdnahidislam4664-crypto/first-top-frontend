import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../controllers/wallet_controller.dart';

class SendGiftDialog extends StatefulWidget {
  final String receiverId;
  final String receiverUsername;

  const SendGiftDialog({
    super.key,
    required this.receiverId,
    required this.receiverUsername,
  });

  @override
  State<SendGiftDialog> createState() => _SendGiftDialogState();
}

class _SendGiftDialogState extends State<SendGiftDialog> {
  final TextEditingController _passwordController = TextEditingController();
  double _selectedCoins = 10;
  bool _isSending = false;

  final List<double> _giftOptions = [5, 10, 25, 50, 100, 500];

  @override
  Widget build(BuildContext context) {
    final walletCtrl = Provider.of<WalletController>(context);

    return AlertDialog(
      backgroundColor: Colors.grey[900],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(
        children: [
          const Icon(Icons.card_giftcard, color: Colors.amber),
          const SizedBox(width: 8),
          Text(
            '@${widget.receiverUsername}-কে কয়েন দিন',
            style: const TextStyle(color: Colors.white, fontSize: 16),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'ব্যালেন্স: ${walletCtrl.walletBalance.toStringAsFixed(0)} Top Coins',
              style: const TextStyle(color: Colors.amberAccent, fontSize: 13),
            ),
            const SizedBox(height: 15),
            const Text('কয়েন পরিমাণ বেছে নিন:', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: _giftOptions.map((coins) {
                final isSelected = _selectedCoins == coins;
                return ChoiceChip(
                  label: Text('${coins.toInt()} 🪙'),
                  selected: isSelected,
                  selectedColor: Colors.amber,
                  backgroundColor: Colors.grey[800],
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.black : Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                  onSelected: (_) => setState(() => _selectedCoins = coins),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _passwordController,
              obscureText: true,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'আপনার পাসওয়ার্ড দিন',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[850],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                prefixIcon: const Icon(Icons.lock, color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('বাতিল', style: TextStyle(color: Colors.grey)),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.amber,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          onPressed: _isSending
              ? null
              : () async {
                  if (_passwordController.text.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('অনুগ্রহ করে পাসওয়ার্ড প্রদান করুন')),
                    );
                    return;
                  }
                  setState(() => _isSending = true);

                  final result = await walletCtrl.sendGiftCoin(
                    receiverId: widget.receiverId,
                    amount: _selectedCoins,
                    password: _passwordController.text,
                  );

                  setState(() => _isSending = false);

                  if (context.mounted) {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(result['message']),
                        backgroundColor: result['success'] ? Colors.green : Colors.red,
                      ),
                    );
                  }
                },
          child: _isSending
              ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                )
              : const Text('পাঠান', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        ),
      ],
    );
  }
}