import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../controllers/wallet_controller.dart';
import 'withdraw_screen.dart'; // উইথড্র স্ক্রিনের লিংক

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() =>
        Provider.of<WalletController>(context, listen: false).fetchWalletData());
  }

  void _showDepositDialog(BuildContext context) {
    final walletCtrl = Provider.of<WalletController>(context, listen: false);
    final amountCtrl = TextEditingController();
    final trxIdCtrl = TextEditingController();
    String selectedMethod = 'bkash';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.grey[900],
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Top Coin কিনুন (ডিপোজিট)',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[850],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('পেমেন্ট পাঠানোর নম্বর (Send Money):',
                        style: TextStyle(color: Colors.white70, fontSize: 12)),
                    const SizedBox(height: 6),
                    Text('বিকাশ: ${walletCtrl.paymentNumbers['bkash'] ?? '01XXXXXXXXX'}',
                        style: const TextStyle(color: Colors.pinkAccent)),
                    Text('নগদ: ${walletCtrl.paymentNumbers['nagad'] ?? '01XXXXXXXXX'}',
                        style: const TextStyle(color: Colors.orangeAccent)),
                  ],
                ),
              ),
              const SizedBox(height: 15),
              Row(
                children: ['bkash', 'nagad'].map((method) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: ChoiceChip(
                      label: Text(method.toUpperCase()),
                      selected: selectedMethod == method,
                      selectedColor: Colors.amber,
                      onSelected: (_) => setModalState(() => selectedMethod = method),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: amountCtrl,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'টাকার পরিমাণ (যেমন: ১০০)',
                  filled: true,
                  fillColor: Colors.grey[800],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: trxIdCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'ট্রানজেকশন আইডি (TrxID)',
                  filled: true,
                  fillColor: Colors.grey[800],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  minimumSize: const Size(double.infinity, 48),
                ),
                onPressed: () async {
                  final amount = double.tryParse(amountCtrl.text) ?? 0;
                  if (amount > 0 && trxIdCtrl.text.isNotEmpty) {
                    final success = await walletCtrl.submitDepositRequest(
                      amount: amount,
                      paymentMethod: selectedMethod,
                      trxId: trxIdCtrl.text,
                    );
                    if (context.mounted) {
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(success
                              ? 'রিকোয়েস্ট জমা হয়েছে! অ্যাডমিন যাচাই করার পর কয়েন যুক্ত হবে।'
                              : 'ব্যর্থ হয়েছে! আবার চেষ্টা করুন।'),
                          backgroundColor: success ? Colors.green : Colors.red,
                        ),
                      );
                    }
                  }
                },
                child: const Text('সাবমিট করুন', style: TextStyle(color: Colors.black)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final walletCtrl = Provider.of<WalletController>(context);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        title: const Text('Top Coin ওয়ালেট', style: TextStyle(color: Colors.white)),
      ),
      body: walletCtrl.isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.amber))
          : Column(
              children: [
                // ব্যালেন্স কার্ড
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.amber, Colors.orangeAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    children: [
                      const Text('বর্তমান ব্যালেন্স',
                          style: TextStyle(color: Colors.black87, fontSize: 14)),
                      const SizedBox(height: 8),
                      Text(
                        '${walletCtrl.walletBalance.toStringAsFixed(0)} 🪙',
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 16),
                      // দুটি বাটন: ডিপোজিট এবং উইথড্র
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.black,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              icon: const Icon(Icons.add_circle, color: Colors.amber),
                              label: const Text('কয়েন কিনুন'),
                              onPressed: () => _showDepositDialog(context),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red[900],
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              icon: const Icon(Icons.outbox, color: Colors.white),
                              label: const Text('টাকা তুলুন'),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => WithdrawScreen(currentBalance: walletCtrl.walletBalance),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'লেনদেন হিস্ট্রি',
                      style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),

                // হিস্ট্রি তালিকা
                Expanded(
                  child: walletCtrl.transactions.isEmpty
                      ? const Center(child: Text('কোনো লেনদেন রেকর্ড নেই', style: TextStyle(color: Colors.grey)))
                      : ListView.builder(
                          itemCount: walletCtrl.transactions.length,
                          itemBuilder: (context, index) {
                            final trx = walletCtrl.transactions[index];
                            final isCompleted = trx.status == 'completed';

                            return Container(
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        trx.type.toUpperCase(),
                                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                      ),
                                      Text(
                                        DateFormat('dd MMM yyyy, hh:mm a').format(trx.createdAt),
                                        style: const TextStyle(color: Colors.grey, fontSize: 11),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        '${trx.amount.toStringAsFixed(0)} 🪙',
                                        style: const TextStyle(
                                          color: Colors.amberAccent,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: isCompleted ? Colors.green[900] : Colors.amber[900],
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text(
                                          trx.status.toUpperCase(),
                                          style: TextStyle(
                                            color: isCompleted ? Colors.greenAccent : Colors.amberAccent,
                                            fontSize: 10,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}