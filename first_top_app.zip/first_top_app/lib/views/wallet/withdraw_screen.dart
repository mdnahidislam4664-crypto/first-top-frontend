import 'package:flutter/material.dart';
import '../../config/api_constants.dart';
import '../../services/api_service.dart';

class WithdrawScreen extends StatefulWidget {
  final double currentBalance;
  const WithdrawScreen({super.key, required this.currentBalance});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  final ApiService _apiService = ApiService();
  final TextEditingController _amountCtrl = TextEditingController();
  final TextEditingController _accountCtrl = TextEditingController();
  final TextEditingController _passCtrl = TextEditingController();
  String _selectedMethod = 'bkash';
  bool _isLoading = false;

  Future<void> _submitWithdraw() async {
    final amount = double.tryParse(_amountCtrl.text.trim()) ?? 0;
    if (amount < 500) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সর্বনিম্ন ৫০০ টাকা উইথড্র করতে হবে!')));
      return;
    }

    setState(() => _isLoading = true);

    try {
      final res = await _apiService.post(
        '${ApiConstants.baseUrl}/wallet/withdraw-request',
        data: {
          'amount': amount,
          'payment_method': _selectedMethod,
          'account_number': _accountCtrl.text.trim(),
          'password': _passCtrl.text,
        },
      );

      setState(() => _isLoading = false);

      if (res.statusCode == 201 && res.data['success']) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('উইথড্র রিকোয়েস্ট সফল হয়েছে! অ্যাডমিন পেমেন্ট পাঠিয়ে দেবেন।'), backgroundColor: Colors.green),
          );
          Navigator.pop(context);
        }
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('ভুল পাসওয়ার্ড অথবা অপর্যাপ্ত ব্যালেন্স!'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.grey[900], title: const Text('টাকা উত্তোলন (Cash Out)')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  const Text('বর্তমান ব্যালেন্স', style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 6),
                  Text(
                    '${widget.currentBalance.toStringAsFixed(0)} 🪙 / ৳',
                    style: const TextStyle(color: Colors.amber, fontSize: 32, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),
            const Text('পেমেন্ট মেথড বেছে নিন:', style: TextStyle(color: Colors.white)),
            const SizedBox(height: 10),
            Row(
              children: ['bkash', 'nagad', 'rocket'].map((method) {
                return Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: ChoiceChip(
                    label: Text(method.toUpperCase()),
                    selected: _selectedMethod == method,
                    selectedColor: Colors.amber,
                    onSelected: (_) => setState(() => _selectedMethod = method),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _accountCtrl,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'মোবাইল অ্যাকাউন্ট নম্বর (01XXXXXXXXX)',
                filled: true,
                fillColor: Colors.grey[900],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _amountCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'টাকার পরিমাণ (মিনিমাম ৫০০)',
                filled: true,
                fillColor: Colors.grey[900],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: _passCtrl,
              obscureText: true,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'নিরাপত্তা পাসওয়ার্ড দিন',
                filled: true,
                fillColor: Colors.grey[900],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 25),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.amber, minimumSize: const Size(double.infinity, 50)),
              onPressed: _isLoading ? null : _submitWithdraw,
              child: _isLoading
                  ? const CircularProgressIndicator(color: Colors.black)
                  : const Text('উইথড্র রিকোয়েস্ট পাঠান', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}