import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../controllers/theme_language_controller.dart';
import '../../controllers/auth_controller.dart';
import '../auth/login_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeLangCtrl = Provider.of<ThemeLanguageController>(context);
    final authCtrl = Provider.of<AuthController>(context);

    return Scaffold(
      backgroundColor: themeLangCtrl.isDarkMode ? Colors.black : Colors.grey[100],
      appBar: AppBar(
        backgroundColor: themeLangCtrl.isDarkMode ? Colors.grey[900] : Colors.white,
        title: Text(
          themeLangCtrl.currentLanguage == 'bn' ? 'সেটিংস ও প্রাইভেসী' : 'Settings & Privacy',
          style: TextStyle(color: themeLangCtrl.isDarkMode ? Colors.white : Colors.black),
        ),
        iconTheme: IconThemeData(color: themeLangCtrl.isDarkMode ? Colors.white : Colors.black),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: [
          // ভাষা নির্বাচন (Language Toggle)
          ListTile(
            leading: const Icon(Icons.language, color: Colors.blueAccent),
            title: Text(themeLangCtrl.currentLanguage == 'bn' ? 'অ্যাপের ভাষা' : 'App Language'),
            subtitle: Text(themeLangCtrl.currentLanguage == 'bn' ? 'বাংলা (Bangla)' : 'English'),
            trailing: DropdownButton<String>(
              value: themeLangCtrl.currentLanguage,
              dropdownColor: themeLangCtrl.isDarkMode ? Colors.grey[900] : Colors.white,
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(value: 'bn', child: Text('বাংলা')),
                DropdownMenuItem(value: 'en', child: Text('English')),
              ],
              onChanged: (val) {
                if (val != null) themeLangCtrl.setLanguage(val);
              },
            ),
          ),
          const Divider(),

          // ডার্ক / লাইট মোড (Theme Toggle)
          SwitchListTile(
            secondary: Icon(
              themeLangCtrl.isDarkMode ? Icons.dark_mode : Icons.light_mode,
              color: Colors.amber,
            ),
            title: Text(themeLangCtrl.currentLanguage == 'bn' ? 'ডার্ক মোড' : 'Dark Mode'),
            subtitle: Text(themeLangCtrl.isDarkMode ? 'ডার্ক থিম সক্রিয়' : 'লাইট থিম সক্রিয়'),
            value: themeLangCtrl.isDarkMode,
            onChanged: (val) => themeLangCtrl.toggleTheme(val),
          ),
          const Divider(),

          // ডাটা সেভার মোড (Data Saver Mode)
          SwitchListTile(
            secondary: const Icon(Icons.data_saver_on, color: Colors.greenAccent),
            title: Text(themeLangCtrl.currentLanguage == 'bn' ? 'ডাটা সেভার মোড' : 'Data Saver'),
            subtitle: Text(themeLangCtrl.currentLanguage == 'bn' ? 'কম মোবাইল ডাটা খরচ করবে' : 'Reduces video data usage'),
            value: themeLangCtrl.isDataSaverOn,
            onChanged: (val) => themeLangCtrl.toggleDataSaver(val),
          ),
          const Divider(),

          // পলিসি লিংকসমূহ
          ListTile(
            leading: const Icon(Icons.privacy_tip_outlined, color: Colors.purpleAccent),
            title: Text(themeLangCtrl.currentLanguage == 'bn' ? 'প্রাইভেসি পলিসি' : 'Privacy Policy'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.description_outlined, color: Colors.tealAccent),
            title: Text(themeLangCtrl.currentLanguage == 'bn' ? 'ব্যবহারের শর্তাবলী' : 'Terms of Service'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {},
          ),
          const Divider(),

          // লগআউট
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.redAccent),
            title: Text(
              themeLangCtrl.currentLanguage == 'bn' ? 'লগআউট করুন' : 'Log Out',
              style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold),
            ),
            onTap: () async {
              await authCtrl.logout();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              }
            },
          ),
        ],
      ),
    );
  }
}