import 'package:flutter/material.dart';

class QrShareScreen extends StatelessWidget {
  final String username;
  final String avatarUrl;

  const QrShareScreen({
    super.key,
    required this.username,
    required this.avatarUrl,
  });

  @override
  Widget build(BuildContext context) {
    // সরাসরি অনলাইন API দিয়ে ডায়নামিক QR কোড তৈরি (কোনো অতিরিক্ত প্লাগইন ছাড়াই)
    final qrApiUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=firsttop://profile/$username';

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        title: const Text('প্রোফাইল কিউআর কোড', style: TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.redAccent.withOpacity(0.3),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 35,
                      backgroundImage: NetworkImage(avatarUrl),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '@$username',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'First Top প্রোফাইল',
                      style: TextStyle(color: Colors.grey, fontSize: 13),
                    ),
                    const SizedBox(height: 20),
                    Image.network(
                      qrApiUrl,
                      height: 200,
                      width: 200,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return const SizedBox(
                          height: 200,
                          width: 200,
                          child: Center(child: CircularProgressIndicator(color: Colors.redAccent)),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              const Text(
                'স্ক্যান করে সহজেই আমাকে First Top-এ ফলো করুন',
                style: TextStyle(color: Colors.white70, fontSize: 14),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}