import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../controllers/monetization_controller.dart';

class CreatorStudioScreen extends StatefulWidget {
  const CreatorStudioScreen({super.key});

  @override
  State<CreatorStudioScreen> createState() => _CreatorStudioScreenState();
}

class _CreatorStudioScreenState extends State<CreatorStudioScreen> {
  @override
  void initState() {
    super.initState();
    final ctrl = Provider.of<MonetizationController>(context, listen: false);
    ctrl.checkEligibility();
    ctrl.fetchCreatorDashboard();
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = Provider.of<MonetizationController>(context);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        title: const Text('Creator Studio', style: TextStyle(color: Colors.white)),
      ),
      body: ctrl.isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.redAccent))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'মনিটাইজেশন যোগ্যতা',
                          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 12),
                        if (ctrl.eligibility != null) ...[
                          _buildProgressBar(
                            label: 'ভিউজ টার্গেট',
                            current: ctrl.eligibility!['current_views'] ?? 0,
                            required: ctrl.eligibility!['required_views'] ?? 10000,
                          ),
                          const SizedBox(height: 10),
                          _buildProgressBar(
                            label: 'ফলোয়ার টার্গেট',
                            current: ctrl.eligibility!['current_followers'] ?? 0,
                            required: ctrl.eligibility!['required_followers'] ?? 1000,
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: (ctrl.eligibility!['is_eligible_for_monetization'] ?? false)
                                  ? Colors.green
                                  : Colors.grey[800],
                              minimumSize: const Size(double.infinity, 45),
                            ),
                            onPressed: (ctrl.eligibility!['is_eligible_for_monetization'] ?? false)
                                ? () {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('মনিটাইজেশনের জন্য আবেদন পাঠানো হয়েছে!')),
                                    );
                                  }
                                : null,
                            child: Text(
                              (ctrl.eligibility!['is_already_monetized'] ?? false)
                                  ? 'মনিটাইজেশন সক্রিয় আছে ✅'
                                  : ((ctrl.eligibility!['is_eligible_for_monetization'] ?? false)
                                      ? 'আবেদন করুন (Apply Now)'
                                      : 'টার্গেট পূরণ হয়নি'),
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text('অ্যানালিটিক্স ওভারভিউ',
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  if (ctrl.analytics != null) ...[
                    Row(
                      children: [
                        Expanded(
                          child: _buildMetricCard(
                            title: 'টোটাল ভিউজ',
                            value: '${ctrl.analytics!['total_views'] ?? 0}',
                            icon: Icons.visibility,
                            color: Colors.lightBlueAccent,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildMetricCard(
                            title: 'আনুমানিক আয়',
                            value: '\$${(ctrl.analytics!['total_estimated_earnings'] ?? 0).toStringAsFixed(2)}',
                            icon: Icons.monetization_on,
                            color: Colors.greenAccent,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _buildMetricCard(
                      title: 'আরপিএম (RPM - প্রতি ১০০০ ভিউতে আয়)',
                      value: '\$${(ctrl.analytics!['rpm'] ?? 0).toStringAsFixed(3)}',
                      icon: Icons.trending_up,
                      color: Colors.amberAccent,
                    ),
                  ],
                ],
              ),
            ),
    );
  }

  Widget _buildProgressBar({required String label, required int current, required int required}) {
    final progress = (current / (required == 0 ? 1 : required)).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(color: Colors.white70, fontSize: 13)),
            Text('$current / $required', style: const TextStyle(color: Colors.white, fontSize: 13)),
          ],
        ),
        const SizedBox(height: 6),
        LinearProgressIndicator(
          value: progress,
          backgroundColor: Colors.grey[800],
          color: progress >= 1.0 ? Colors.green : Colors.redAccent,
          minHeight: 6,
        ),
      ],
    );
  }

  Widget _buildMetricCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}