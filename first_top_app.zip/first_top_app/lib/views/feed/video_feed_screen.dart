import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../controllers/video_controller.dart';
import '../../services/api_service.dart';
import '../../config/api_constants.dart';
import '../../models/video_model.dart';
import '../discover/discover_screen.dart';
import '../notifications/notifications_screen.dart';
import 'widgets/video_player_item.dart';

class VideoFeedScreen extends StatefulWidget {
  const VideoFeedScreen({super.key});

  @override
  State<VideoFeedScreen> createState() => _VideoFeedScreenState();
}

class _VideoFeedScreenState extends State<VideoFeedScreen> {
  final ApiService _apiService = ApiService();
  late PageController _pageController;
  int _currentPage = 0;
  String _selectedTab = 'For You';
  List<VideoModel> _nearbyVideos = [];
  bool _isLoadingNearby = false;

  // ফিচার ৫: অটো-স্ক্রোল স্টেট
  bool _isAutoScrollEnabled = false;

  // ফিচার ১৪: ইন্টারনেট ডিটেক্টর স্টেট
  bool _isOffline = false;
  Timer? _networkTimer;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    Future.microtask(() =>
        Provider.of<VideoController>(context, listen: false).fetchFeed());

    _startNetworkMonitoring();
  }

  // ফিচার ১৪: ইন্টারনেট সংযোগ চেক করা
  void _startNetworkMonitoring() {
    _networkTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      try {
        final result = await InternetAddress.lookup('google.com');
        if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
          if (_isOffline && mounted) setState(() => _isOffline = false);
        }
      } on SocketException catch (_) {
        if (!_isOffline && mounted) setState(() => _isOffline = true);
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _networkTimer?.cancel();
    super.dispose();
  }

  // জিপিএস Nearby ভিডিও লোড
  Future<void> _fetchNearbyVideos() async {
    setState(() => _isLoadingNearby = true);
    try {
      final res = await _apiService.get('${ApiConstants.baseUrl}/social/videos/nearby?longitude=90.4125&latitude=23.8103');
      if (res.statusCode == 200 && res.data['success']) {
        final List list = res.data['data'];
        setState(() {
          _nearbyVideos = list.map((e) => VideoModel.fromJson(e)).toList();
        });
      }
    } catch (_) {}
    setState(() => _isLoadingNearby = false);
  }

  // ফিচার ৫: ভিডিও শেষ হলে স্বয়ংক্রিয়ভাবে পরের ভিডিওতে যাওয়া
  void _handleVideoEnded(int totalVideos) {
    if (_isAutoScrollEnabled && _currentPage < totalVideos - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final videoController = Provider.of<VideoController>(context);
    final displayVideos = _selectedTab == 'Nearby' ? _nearbyVideos : videoController.videos;
    final isLoading = _selectedTab == 'Nearby' ? _isLoadingNearby : videoController.isLoading;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // উল্লম্ব ভিডিও পেজার
          isLoading
              ? const Center(child: CircularProgressIndicator(color: Colors.redAccent))
              : displayVideos.isEmpty
                  ? Center(
                      child: Text(
                        _selectedTab == 'Nearby' ? 'আপনার এলাকায় এখনও কোনো ভিডিও নেই!' : 'কোনো ভিডিও পাওয়া যায়নি!',
                        style: const TextStyle(color: Colors.grey),
                      ),
                    )
                  : PageView.builder(
                      controller: _pageController,
                      scrollDirection: Axis.vertical,
                      itemCount: displayVideos.length,
                      onPageChanged: (index) {
                        setState(() => _currentPage = index);
                        videoController.onVideoSwiped(displayVideos[index].id);
                      },
                      itemBuilder: (context, index) {
                        return VideoPlayerItem(
                          video: displayVideos[index],
                          isCurrent: index == _currentPage,
                          onVideoEnded: () => _handleVideoEnded(displayVideos.length), // ফিচার ৫ কলব্যাক
                        );
                      },
                    ),

          // ফিচার ১৪: অফলাইন / দুর্বল নেটওয়ার্ক ব্যানার
          if (_isOffline)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                color: Colors.redAccent,
                padding: const EdgeInsets.only(top: 36, bottom: 6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.wifi_off, color: Colors.white, size: 16),
                    SizedBox(width: 8),
                    Text(
                      'ইন্টারনেট সংযোগ নেই! ভিডিও লোড হতে দেরি হতে পারে।',
                      style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),

          // ওপরের হেডার বার (Search | Tabs | Auto-Scroll Toggle | Notifications)
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // সার্চ বাটন
                  IconButton(
                    icon: const Icon(Icons.search, color: Colors.white, size: 26),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const DiscoverScreen()),
                      );
                    },
                  ),

                  // ৩টি ট্যাব (Following | For You | Nearby)
                  Row(
                    children: [
                      _buildTabButton('Following'),
                      const SizedBox(width: 10),
                      _buildTabButton('For You'),
                      const SizedBox(width: 10),
                      _buildTabButton('Nearby'),
                    ],
                  ),

                  // ফিচার ৫: অটো-স্ক্রোল বাটন (হ্যান্ডস-ফ্রি মোড)
                  IconButton(
                    icon: Icon(
                      _isAutoScrollEnabled ? Icons.play_circle_filled : Icons.play_circle_outline,
                      color: _isAutoScrollEnabled ? Colors.redAccent : Colors.white70,
                      size: 26,
                    ),
                    onPressed: () {
                      setState(() => _isAutoScrollEnabled = !_isAutoScrollEnabled);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(_isAutoScrollEnabled ? 'অটো-স্ক্রোল মোড চালু হয়েছে! 🔄' : 'অটো-স্ক্রোল বন্ধ করা হয়েছে।'),
                          duration: const Duration(seconds: 1),
                        ),
                      );
                    },
                  ),

                  // নোটিফিকেশন বাটন
                  IconButton(
                    icon: const Icon(Icons.notifications_none, color: Colors.white, size: 26),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const NotificationsScreen()),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(String title) {
    final isSelected = _selectedTab == title;
    return GestureDetector(
      onTap: () {
        setState(() => _selectedTab = title);
        if (title == 'Nearby') {
          _fetchNearbyVideos();
        }
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            title,
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.white60,
              fontSize: isSelected ? 16 : 14,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          if (isSelected) ...[
            const SizedBox(height: 4),
            Container(height: 2, width: 24, color: Colors.redAccent),
          ],
        ],
      ),
    );
  }
}