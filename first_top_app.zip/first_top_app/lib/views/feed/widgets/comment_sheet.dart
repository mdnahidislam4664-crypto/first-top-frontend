import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../config/api_constants.dart';
import '../../../models/comment_model.dart';
import '../../../services/api_service.dart';

class CommentSheet extends StatefulWidget {
  final String videoId;
  const CommentSheet({super.key, required this.videoId});

  @override
  State<CommentSheet> createState() => _CommentSheetState();
}

class _CommentSheetState extends State<CommentSheet> {
  final ApiService _apiService = ApiService();
  final TextEditingController _commentCtrl = TextEditingController();
  List<CommentModel> _comments = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchComments();
  }

  // ব্যাক-এন্ড থেকে কমেন্ট তালিকা আনা (পিনড কমেন্ট সবার আগে আসবে)
  Future<void> _fetchComments() async {
    try {
      final res = await _apiService.get('${ApiConstants.baseUrl}/social/videos/${widget.videoId}/comments');
      if (res.statusCode == 200 && res.data['success']) {
        final List list = res.data['data'];
        setState(() {
          _comments = list.map((e) => CommentModel.fromJson(e)).toList();
          _isLoading = false;
        });
      }
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  // নতুন কমেন্ট পোস্ট করা
  Future<void> _postComment() async {
    final text = _commentCtrl.text.trim();
    if (text.isEmpty) return;

    _commentCtrl.clear();
    try {
      final res = await _apiService.post(
        '${ApiConstants.baseUrl}/social/videos/${widget.videoId}/comments',
        data: {'text': text},
      );
      if (res.statusCode == 201 && res.data['success']) {
        _fetchComments(); // সাথে সাথে তালিকা রিফ্রেশ করা
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.65,
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            height: 4,
            width: 40,
            decoration: BoxDecoration(color: Colors.grey[600], borderRadius: BorderRadius.circular(2)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              '${_comments.length} টি মন্তব্য',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          const Divider(color: Colors.grey, height: 1),

          // কমেন্ট লিস্ট
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: Colors.redAccent))
                : _comments.isEmpty
                    ? const Center(
                        child: Text('এখনও কোনো মন্তব্য নেই। প্রথম মন্তব্যটি করুন!', style: TextStyle(color: Colors.grey)),
                      )
                    : ListView.builder(
                        itemCount: _comments.length,
                        itemBuilder: (context, index) {
                          final c = _comments[index];
                          return ListTile(
                            leading: CircleAvatar(
                              radius: 18,
                              backgroundImage: NetworkImage(c.userAvatar),
                            ),
                            title: Row(
                              children: [
                                Text('@${c.username}', style: const TextStyle(color: Colors.grey, fontSize: 13)),
                                if (c.isPinned) ...[
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                    decoration: BoxDecoration(color: Colors.redAccent, borderRadius: BorderRadius.circular(4)),
                                    child: const Text('📌 Pinned', style: TextStyle(color: Colors.white, fontSize: 10)),
                                  ),
                                ],
                              ],
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                Text(c.text, style: const TextStyle(color: Colors.white)),
                                const SizedBox(height: 4),
                                Text(
                                  DateFormat('dd MMM, hh:mm a').format(c.createdAt),
                                  style: const TextStyle(color: Colors.white38, fontSize: 10),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),

          // কমেন্ট লেখার ইনপুট বার
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            color: Colors.black,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _commentCtrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'একটি মন্তব্য লিখুন...',
                      hintStyle: const TextStyle(color: Colors.grey),
                      filled: true,
                      fillColor: Colors.grey[850],
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(25), borderSide: BorderSide.none),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.redAccent),
                  onPressed: _postComment,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}