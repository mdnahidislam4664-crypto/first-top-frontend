import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../../models/video_model.dart';
import '../../../controllers/video_controller.dart';
import 'comment_sheet.dart';

class VideoPlayerItem extends StatefulWidget {
  final VideoModel video;
  final bool isCurrent;
  final VoidCallback? onVideoEnded; // অটো-স্ক্রোলের জন্য

  const VideoPlayerItem({
    super.key,
    required this.video,
    required this.isCurrent,
    this.onVideoEnded,
  });

  @override
  State<VideoPlayerItem> createState() => _VideoPlayerItemState();
}

class _VideoPlayerItemState extends State<VideoPlayerItem> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _showHeartAnimation = false;
  bool _showMuteIndicator = false;
  bool _isMuted = false;
  bool _isFastForwarding = false;
  Timer? _threeSecondTimer;
  bool _hasTrackedView = false;
  double _playbackSpeed = 1.0;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  void _initVideo() {
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.video.videoUrl))
      ..initialize().then((_) {
        setState(() => _isInitialized = true);
        if (widget.isCurrent) {
          _playAndStartTimer();
        }
      });

    // অটো-স্ক্রোল লিসেনার (ভিডিও শেষ হলে)
    _controller.addListener(() {
      if (_controller.value.isInitialized &&
          _controller.value.position >= _controller.value.duration &&
          !_controller.value.isPlaying) {
        widget.onVideoEnded?.call();
      }
    });
  }

  @override
  void didUpdateWidget(covariant VideoPlayerItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isCurrent) {
      _playAndStartTimer();
    } else {
      _controller.pause();
      _threeSecondTimer?.cancel();
    }
  }

  void _playAndStartTimer() {
    _controller.play();
    if (!_hasTrackedView) {
      _threeSecondTimer?.cancel();
      _threeSecondTimer = Timer(const Duration(seconds: 3), () {
        if (mounted && _controller.value.isPlaying) {
          _hasTrackedView = true;
          Provider.of<VideoController>(context, listen: false)
              .trackThreeSecondView(widget.video.id);
        }
      });
    }
  }

  @override
  void dispose() {
    _threeSecondTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  // ফিচার ২: এক ট্যাপে মিউট / আনমিউট
  void _toggleMute() {
    setState(() {
      _isMuted = !_isMuted;
      _controller.setVolume(_isMuted ? 0.0 : 1.0);
      _showMuteIndicator = true;
    });
    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _showMuteIndicator = false);
    });
  }

  // ডাবল ট্যাপে লাভ অ্যানিমেশন
  void _onDoubleTap() {
    setState(() => _showHeartAnimation = true);
    Provider.of<VideoController>(context, listen: false).toggleLike(widget.video);
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) setState(() => _showHeartAnimation = false);
    });
  }

  // ফিচার ৪: ভিডিও স্পিড সিলেক্টর মেনু
  void _showSpeedMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'প্লেব্যাক স্পিড বেছে নিন',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [0.5, 1.0, 1.5, 2.0].map((speed) {
                final isSelected = _playbackSpeed == speed;
                return ChoiceChip(
                  label: Text('${speed}x'),
                  selected: isSelected,
                  selectedColor: Colors.redAccent,
                  backgroundColor: Colors.grey[800],
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.white : Colors.white70,
                    fontWeight: FontWeight.bold,
                  ),
                  onSelected: (_) {
                    setState(() {
                      _playbackSpeed = speed;
                      _controller.setPlaybackSpeed(speed);
                    });
                    Navigator.pop(context);
                  },
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  // ফিচার ১৩: স্মার্ট শেয়ার ও এক ক্লিকে লিংক কপি
  void _showShareSheet() {
    final videoLink = 'https://firsttop.app/video/${widget.video.id}';

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'শেয়ার করুন',
              style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // লিংক কপি বাটন
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: videoLink));
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('ভিডিও লিংক কপি করা হয়েছে! 📋'), backgroundColor: Colors.green),
                    );
                  },
                  child: Column(
                    children: const [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: Colors.blueAccent,
                        child: Icon(Icons.link, color: Colors.white),
                      ),
                      SizedBox(height: 8),
                      Text('লিংক কপি', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
                // হোয়াটসঅ্যাপ শেয়ার
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: 'First Top-এ এই চমৎকার ভিডিওটি দেখুন: $videoLink'));
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('টেক্সট কপি হয়েছে! হোয়াটসঅ্যাপে পেস্ট করুন।'), backgroundColor: Colors.green),
                    );
                  },
                  child: Column(
                    children: const [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: Colors.green,
                        child: Icon(Icons.chat, color: Colors.white),
                      ),
                      SizedBox(height: 8),
                      Text('WhatsApp', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
                // রিপোর্ট অপশন
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('রিপোর্ট গ্রহণ করা হয়েছে!'), backgroundColor: Colors.orange),
                    );
                  },
                  child: Column(
                    children: const [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: Colors.redAccent,
                        child: Icon(Icons.flag, color: Colors.white),
                      ),
                      SizedBox(height: 8),
                      Text('রিপোর্ট', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _toggleMute, // ফিচার ২: ট্যাপে মিউট / আনমিউট
      onDoubleTap: _onDoubleTap,
      // ফিচার ১: লং-প্রেসে ২x স্পিড শুরু
      onLongPressStart: (_) {
        setState(() => _isFastForwarding = true);
        _controller.setPlaybackSpeed(2.0);
      },
      // ফিচার ১: আঙুল তুললে স্বাভাবিক ১x স্পিডে ফেরা
      onLongPressEnd: (_) {
        setState(() => _isFastForwarding = false);
        _controller.setPlaybackSpeed(_playbackSpeed);
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          // মূল ভিডিও স্ক্রিন
          _isInitialized
              ? FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _controller.value.size.width,
                    height: _controller.value.size.height,
                    child: VideoPlayer(_controller),
                  ),
                )
              : const Center(child: CircularProgressIndicator(color: Colors.redAccent)),

          // ফিচার ১: ২x স্পিড চলাকালীন ওপরে সুন্দর ব্যাজ
          if (_isFastForwarding)
            Positioned(
              top: 80,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.redAccent, width: 1.5),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(Icons.fast_forward, color: Colors.redAccent, size: 18),
                      SizedBox(width: 6),
                      Text(
                        '2X স্পিড চলছে',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // ফিচার ২: মিউট / আনমিউট আইকন ফ্ল্যাশ
          if (_showMuteIndicator)
            Center(
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _isMuted ? Icons.volume_off : Icons.volume_up,
                  color: Colors.white,
                  size: 48,
                ),
              ).animate().scale(duration: 200.ms).fadeOut(duration: 600.ms),
            ),

          // ডাবল ট্যাপ হার্ট অ্যানিমেশন
          if (_showHeartAnimation)
            Center(
              child: const Icon(Icons.favorite, color: Colors.redAccent, size: 100)
                  .animate()
                  .scale(duration: 400.ms, curve: Curves.elasticOut)
                  .fadeOut(duration: 400.ms),
            ),

          // ডানপাশের ফ্লোটিং বাটনসমূহ
          Positioned(
            right: 15,
            bottom: 40,
            child: Column(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundImage: NetworkImage(widget.video.userAvatar),
                ),
                const SizedBox(height: 18),
                // লাইক বাটন
                IconButton(
                  icon: Icon(
                    widget.video.isLiked ? Icons.favorite : Icons.favorite_border,
                    color: widget.video.isLiked ? Colors.redAccent : Colors.white,
                    size: 36,
                  ),
                  onPressed: () => Provider.of<VideoController>(context, listen: false).toggleLike(widget.video),
                ),
                Text('${widget.video.likesCount}', style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 14),

                // কমেন্ট বাটন
                IconButton(
                  icon: const Icon(Icons.comment, color: Colors.white, size: 34),
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (_) => CommentSheet(videoId: widget.video.id),
                    );
                  },
                ),
                Text('${widget.video.commentsCount}', style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 14),

                // ফিচার ১৩: শেয়ার বাটন
                IconButton(
                  icon: const Icon(Icons.share, color: Colors.white, size: 34),
                  onPressed: _showShareSheet,
                ),
                Text('${widget.video.sharesCount}', style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 14),

                // ফিচার ৪: ভিডিও স্পিড বাটন (⚡)
                IconButton(
                  icon: const Icon(Icons.speed, color: Colors.amberAccent, size: 30),
                  onPressed: _showSpeedMenu,
                ),
                const Text('স্পিড', style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),

          // ক্যাপশন ও ইউজারনেম
          Positioned(
            left: 15,
            bottom: 25,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '@${widget.video.username}',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 6),
                Text(widget.video.caption, style: const TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 6),
                Row(
                  children: widget.video.tags
                      .map((t) => Text('#$t ', style: const TextStyle(color: Colors.lightBlueAccent)))
                      .toList(),
                ),
              ],
            ),
          ),

          // ফিচার ৩: ভিডিও সিক বার ও স্ক্রাবিং লাইন (একদম নিচে)
          if (_isInitialized)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: SizedBox(
                height: 12,
                child: VideoProgressIndicator(
                  _controller,
                  allowScrubbing: true, // আঙুল দিয়ে টেনে আগে-পিছে করা যাবে
                  colors: const VideoProgressColors(
                    playedColor: Colors.redAccent,
                    bufferedColor: Colors.white24,
                    backgroundColor: Colors.white12,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}