import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:provider/provider.dart';
import '../../controllers/upload_controller.dart';

class PreviewPublishScreen extends StatefulWidget {
  final File videoFile;
  const PreviewPublishScreen({super.key, required this.videoFile});

  @override
  State<PreviewPublishScreen> createState() => _PreviewPublishScreenState();
}

class _PreviewPublishScreenState extends State<PreviewPublishScreen> {
  late VideoPlayerController _controller;
  final TextEditingController _captionController = TextEditingController();
  final TextEditingController _tagsController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(widget.videoFile)
      ..initialize().then((_) {
        setState(() {});
        _controller.setLooping(true);
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    _captionController.dispose();
    _tagsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uploadCtrl = Provider.of<UploadController>(context);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('ভিডিও পোস্ট করুন', style: TextStyle(color: Colors.white)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              SizedBox(
                height: 250,
                child: _controller.value.isInitialized
                    ? AspectRatio(
                        aspectRatio: _controller.value.aspectRatio,
                        child: VideoPlayer(_controller),
                      )
                    : const Center(child: CircularProgressIndicator(color: Colors.redAccent)),
              ),
              const SizedBox(height: 20),

              TextField(
                controller: _captionController,
                style: const TextStyle(color: Colors.white),
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'একটি আকর্ষণীয় ক্যাপশন লিখুন...',
                  hintStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: Colors.grey[900],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(height: 15),

              TextField(
                controller: _tagsController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'হ্যাশট্যাগ লিখুন (যেমন: viral, funny)',
                  hintStyle: const TextStyle(color: Colors.grey),
                  filled: true,
                  fillColor: Colors.grey[900],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(height: 30),

              if (uploadCtrl.isUploading) ...[
                LinearProgressIndicator(
                  value: uploadCtrl.uploadProgress,
                  color: Colors.redAccent,
                  backgroundColor: Colors.grey[800],
                ),
                const SizedBox(height: 10),
                Text(
                  '${(uploadCtrl.uploadProgress * 100).toStringAsFixed(1)}% - ${uploadCtrl.statusMessage}',
                  style: const TextStyle(color: Colors.white70),
                ),
                const SizedBox(height: 20),
              ],

              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: uploadCtrl.isUploading
                    ? null
                    : () async {
                        final tags = _tagsController.text
                            .split(',')
                            .map((e) => e.trim().replaceAll('#', ''))
                            .where((e) => e.isNotEmpty)
                            .toList();

                        final result = await uploadCtrl.publishVideo(
                          videoFile: widget.videoFile,
                          caption: _captionController.text,
                          tags: tags,
                        );

                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(result['message']),
                              backgroundColor: result['success'] ? Colors.green : Colors.red,
                            ),
                          );
                          if (result['success']) {
                            Navigator.popUntil(context, (route) => route.isFirst);
                          }
                        }
                      },
                child: const Text('পাবলিশ করুন', style: TextStyle(fontSize: 16, color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}