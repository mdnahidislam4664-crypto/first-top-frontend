import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../../config/api_constants.dart';
import '../../services/api_service.dart';
import '../auth/login_screen.dart';
import '../home/main_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final ApiService _apiService = ApiService();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
    _fastLaunch();
  }

  // ফাস্ট স্টার্টআপ লজিক (Non-blocking)
  Future<void> _fastLaunch() async {
    // ১. ব্যাকগ্রাউন্ডে ব্যাক-এন্ডে পিং পাঠানো (যাতে ঘুমিয়ে থাকলে জেগে যায়)
    _apiService.get(ApiConstants.settings).catchError((_) {});

    // ২. মাত্র ১ সেকেন্ড লোগো দেখিয়ে সাথে সাথে টোকেন চেক
    await Future.delayed(const Duration(milliseconds: 1200));

    final token = await _storage.read(key: 'jwt_token');

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => token != null 
              ? const MainScreen()   // লগইন থাকলে সরাসরি ১ সেকেন্ডে ভিডিও ফিড
              : const LoginScreen(),  // না থাকলে লগইন পেজ
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Spacer(),
            Text(
              'First Top',
              style: TextStyle(
                color: Colors.white,
                fontSize: 42,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            SizedBox(height: 15),
            CircularProgressIndicator(color: Colors.redAccent),
            Spacer(),
            Text(
              'Made in Bangladesh 🇧🇩',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            SizedBox(height: 35),
          ],
        ),
      ),
    );
  }
}