import 'package:flutter/material.dart';
import '../config/api_constants.dart';
import '../models/transaction_model.dart';
import '../services/api_service.dart';

class WalletController with ChangeNotifier {
  final ApiService _apiService = ApiService();

  double _walletBalance = 0.0;
  List<TransactionModel> _transactions = [];
  bool _isLoading = false;
  Map<String, dynamic> _paymentNumbers = {};

  double get walletBalance => _walletBalance;
  List<TransactionModel> get transactions => _transactions;
  bool get isLoading => _isLoading;
  Map<String, dynamic> get paymentNumbers => _paymentNumbers;

  // ব্যালেন্স, বিকাশ/নগদ নম্বর ও হিস্ট্রি ফেচ করা
  Future<void> fetchWalletData() async {
    _isLoading = true;
    notifyListeners();

    try {
      final userRes = await _apiService.get(ApiConstants.getMe);
      if (userRes.statusCode == 200 && userRes.data['success']) {
        _walletBalance = (userRes.data['data']['wallet_balance'] ?? 0).toDouble();
      }

      final settingsRes = await _apiService.get(ApiConstants.settings);
      if (settingsRes.statusCode == 200 && settingsRes.data['success']) {
        _paymentNumbers = settingsRes.data['data']['payment_numbers'] ?? {};
      }

      final trxRes = await _apiService.get(ApiConstants.myTransactions);
      if (trxRes.statusCode == 200 && trxRes.data['success']) {
        final List list = trxRes.data['data'];
        _transactions = list.map((e) => TransactionModel.fromJson(e)).toList();
      }
    } catch (e) {
      debugPrint('[Wallet Error]: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  // কয়েন গিফট পাঠানো (পাসওয়ার্ড প্রোটেক্টেড Atomic Transaction)
  Future<Map<String, dynamic>> sendGiftCoin({
    required String receiverId,
    required double amount,
    required String password,
  }) async {
    try {
      final res = await _apiService.post(
        ApiConstants.sendGift,
        data: {
          'receiver_id': receiverId,
          'amount': amount,
          'password': password,
        },
      );

      if (res.statusCode == 200 && res.data['success']) {
        _walletBalance -= amount;
        notifyListeners();
        fetchWalletData();
        return {'success': true, 'message': '$amount কয়েন সফলভাবে পাঠানো হয়েছে!'};
      }
    } catch (e) {
      return {'success': false, 'message': 'ভুল পাসওয়ার্ড অথবা অপর্যাপ্ত ব্যালেন্স!'};
    }
    return {'success': false, 'message': 'লেনদেন ব্যর্থ হয়েছে!'};
  }

  // ডিপোজিট রিকোয়েস্ট জমা দেওয়া
  Future<bool> submitDepositRequest({
    required double amount,
    required String paymentMethod,
    required String trxId,
  }) async {
    try {
      final res = await _apiService.post(
        ApiConstants.depositRequest,
        data: {
          'amount': amount,
          'payment_method': paymentMethod.toLowerCase(),
          'transaction_id': trxId.trim(),
        },
      );

      if (res.statusCode == 201 && res.data['success']) {
        fetchWalletData();
        return true;
      }
    } catch (_) {}
    return false;
  }
}