import 'package:flutter/material.dart';
import '../config/api_constants.dart';
import '../models/video_model.dart';
import '../services/api_service.dart';

class VideoController with ChangeNotifier {
  final ApiService _apiService = ApiService();

  List<VideoModel> _videos = [];
  bool _isLoading = false;
  int _adFrequency = 5; // প্রতি ৫টি ভিডিও পর পর অ্যাড
  int _watchedCount = 0;

  List<VideoModel> get videos => _videos;
  bool get isLoading => _isLoading;

  // ব্যাক-এন্ড থেকে ফর-ইউ ভিডিও ফিড লোড করা
  Future<void> fetchFeed({int page = 1}) async {
    if (page == 1) _isLoading = true;
    notifyListeners();

    try {
      final response = await _apiService.get(
        ApiConstants.feed,
        queryParameters: {'page': page, 'limit': 10},
      );

      if (response.statusCode == 200 && response.data['success']) {
        final List list = response.data['data'];
        final fetched = list.map((e) => VideoModel.fromJson(e)).toList();
        if (page == 1) {
          _videos = fetched;
        } else {
          _videos.addAll(fetched);
        }
      }
    } catch (e) {
      debugPrint('[Feed Error]: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  // ৩-সেকেন্ড হাইলাইট রুল ট্র্যাকার API (Render ব্যাক-এন্ডে হিট করে)
  Future<void> trackThreeSecondView(String videoId) async {
    try {
      await _apiService.post(
        '${ApiConstants.viewDuration}/$videoId/view',
        data: {'duration_seconds': 3},
      );
      debugPrint('[Algorithm Triggered]: 3-Second View Recorded for $videoId');
    } catch (e) {
      debugPrint('[View Track Error]: $e');
    }
  }

  // স্ক্রোল কাউন্টার ও ডায়নামিক অ্যাড ট্র্রিগার
  void onVideoSwiped(String currentVideoId) {
    _watchedCount++;
    if (_watchedCount >= _adFrequency) {
      _watchedCount = 0;
      _triggerAdImpression(currentVideoId);
    }
  }

  // অ্যাড ইমপ্রেশন ব্যাক-এন্ডে রিপোর্ট (৫০% ক্রিয়েটর রেভিনিউ শেয়ারিং)
  Future<void> _triggerAdImpression(String videoId) async {
    try {
      await _apiService.post(
        ApiConstants.adImpression,
        data: {'video_id': videoId},
      );
      debugPrint('[Ad Impression]: 50% Revenue Split Recorded for $videoId');
    } catch (e) {
      debugPrint('[Ad Impression Error]: $e');
    }
  }

  // লাইক বাটন টগল
  void toggleLike(VideoModel video) {
    video.isLiked = !video.isLiked;
    if (video.isLiked) {
      video.likesCount++;
    } else {
      video.likesCount--;
    }
    notifyListeners();
  }
}