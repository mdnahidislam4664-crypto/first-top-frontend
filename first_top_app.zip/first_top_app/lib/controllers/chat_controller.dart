import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../config/api_constants.dart';
import '../models/chat_model.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';

class ChatController with ChangeNotifier {
  final ApiService _apiService = ApiService();
  final SocketService _socketService = SocketService();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  List<ChatMessageModel> _messages = [];
  bool _isLoading = false;
  bool _isReceiverTyping = false;
  String _currentReceiverId = '';

  List<ChatMessageModel> get messages => _messages;
  bool get isLoading => _isLoading;
  bool get isReceiverTyping => _isReceiverTyping;

  Future<void> connectSocket() async {
    final token = await _storage.read(key: 'jwt_token');
    if (token != null) {
      _socketService.initSocket(token);
      _setupSocketListeners();
    }
  }

  void _setupSocketListeners() {
    final socket = _socketService.socket;
    if (socket == null) return;

    // ১. নিজের পাঠানো মেসেজ ডেটাবেসে সেভ হওয়ার কনফার্মেশন
    socket.off('message_sent');
    socket.on('message_sent', (data) {
      final msg = ChatMessageModel.fromJson(data);
      if (msg.receiverId == _currentReceiverId) {
        _messages.add(msg);
        notifyListeners();
      }
    });

    // ২. নতুন মেসেজ গ্রহণ করা
    socket.off('receive_message');
    socket.on('receive_message', (data) {
      final msg = ChatMessageModel.fromJson(data);
      if (msg.senderId == _currentReceiverId) {
        _messages.add(msg);
        _socketService.markAsSeen(_currentReceiverId);
        notifyListeners();
      }
    });

    // ৩. ডেলিভারি স্ট্যাটাস আপডেট (Delivered: 1)
    socket.off('message_status_update');
    socket.on('message_status_update', (data) {
      final messageId = data['messageId'];
      final status = data['status'];
      final index = _messages.indexWhere((m) => m.id == messageId);
      if (index != -1) {
        _messages[index].status = status;
        notifyListeners();
      }
    });

    // ৪. Seen আপডেট (Seen: 2)
    socket.off('conversation_seen');
    socket.on('conversation_seen', (data) {
      for (var msg in _messages) {
        msg.status = 2;
      }
      notifyListeners();
    });

    // ৫. টাইপিং ইন্ডিকেটর
    socket.off('user_typing');
    socket.on('user_typing', (data) {
      if (data['senderId'] == _currentReceiverId) {
        _isReceiverTyping = data['isTyping'] ?? false;
        notifyListeners();
      }
    });
  }

  // REST API দিয়ে আগের চ্যাট হিস্ট্রি আনা
  Future<void> fetchChatHistory(String receiverId) async {
    _currentReceiverId = receiverId;
    _isLoading = true;
    _messages.clear();
    notifyListeners();

    try {
      final res = await _apiService.get('${ApiConstants.chatHistory}/$receiverId');
      if (res.statusCode == 200 && res.data['success']) {
        final List list = res.data['data'];
        _messages = list.map((e) => ChatMessageModel.fromJson(e)).toList();
      }
    } catch (_) {}

    _isLoading = false;
    notifyListeners();
    _socketService.markAsSeen(receiverId);
  }

  void sendMessage(String text) {
    if (text.trim().isEmpty) return;
    _socketService.sendMessage(
      receiverId: _currentReceiverId,
      text: text.trim(),
    );
  }

  void sendTypingStatus(bool isTyping) {
    _socketService.emitTyping(
      receiverId: _currentReceiverId,
      isTyping: isTyping,
    );
  }
}