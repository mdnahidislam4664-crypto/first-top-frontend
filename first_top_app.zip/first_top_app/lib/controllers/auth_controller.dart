import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../config/api_constants.dart';
import '../services/api_service.dart';

class AuthController with ChangeNotifier {
  final ApiService _apiService = ApiService();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  bool _isLoading = false;
  Map<String, dynamic>? _user;
  String? _errorMessage;

  bool get isLoading => _isLoading;
  Map<String, dynamic>? get user => _user;
  String? get errorMessage => _errorMessage;

  // লগইন
  Future<bool> login(String identifier, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final res = await _apiService.post(
        ApiConstants.login,
        data: {
          'identifier': identifier.trim(),
          'password': password,
        },
      );

      if (res.statusCode == 200 && res.data['success']) {
        final token = res.data['data']['token'];
        _user = res.data['data'];
        await _storage.write(key: 'jwt_token', value: token);
        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      _errorMessage = 'লগইন ব্যর্থ হয়েছে! ক্রেডেনশিয়াল সঠিক কি না দেখুন।';
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  // সাইন-আপ (রেজিস্ট্রেশন)
  Future<bool> register(String username, String email, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final res = await _apiService.post(
        ApiConstants.register,
        data: {
          'username': username.trim().toLowerCase(),
          'email': email.trim().toLowerCase(),
          'password': password,
        },
      );

      if (res.statusCode == 201 && res.data['success']) {
        final token = res.data['data']['token'];
        _user = res.data['data'];
        await _storage.write(key: 'jwt_token', value: token);
        _isLoading = false;
        notifyListeners();
        return true;
      }
    } catch (e) {
      _errorMessage = 'রেজিস্ট্রেশন ব্যর্থ হয়েছে! অন্য ইউজারনেম ব্যবহার করুন।';
    }

    _isLoading = false;
    notifyListeners();
    return false;
  }

  // লগআউট
  Future<void> logout() async {
    await _storage.delete(key: 'jwt_token');
    _user = null;
    notifyListeners();
  }
}