import 'dart:io';
import 'package:flutter/material.dart';
import '../config/api_constants.dart';
import '../services/api_service.dart';
import '../services/b2_upload_service.dart';

class UploadController with ChangeNotifier {
  final B2UploadService _b2Service = B2UploadService();
  final ApiService _apiService = ApiService();

  bool _isUploading = false;
  double _uploadProgress = 0.0;
  String _statusMessage = '';

  bool get isUploading => _isUploading;
  double get uploadProgress => _uploadProgress;
  String get statusMessage => _statusMessage;

  // ভিডিও আপলোড ও Hive AI ভ্যালিডেশন ফ্লো
  Future<Map<String, dynamic>> publishVideo({
    required File videoFile,
    required String caption,
    required List<String> tags,
  }) async {
    _isUploading = true;
    _uploadProgress = 0.0;
    _statusMessage = 'ক্লাউডে ভিডিও আপলোড হচ্ছে...';
    notifyListeners();

    try {
      // ১. সরাসরি Backblaze B2 তে আপলোড
      final fileUrl = await _b2Service.uploadMediaDirectToB2(
        videoFile,
        onProgress: (sent, total) {
          _uploadProgress = sent / total;
          notifyListeners();
        },
      );

      if (fileUrl == null) {
        throw Exception('Backblaze B2 আপলোড ব্যর্থ হয়েছে!');
      }

      // ২. ব্যাক-এন্ডে পাবলিশ ও Hive AI দিয়ে ভিডিও স্ক্যান করা
      _statusMessage = 'এআই দ্বারা ভিডিও যাচাই করা হচ্ছে...';
      notifyListeners();

      final publishResponse = await _apiService.post(
        ApiConstants.publishVideo,
        data: {
          'video_url': fileUrl,
          'caption': caption,
          'tags': tags,
        },
      );

      _isUploading = false;
      notifyListeners();

      if (publishResponse.statusCode == 201 && publishResponse.data['success']) {
        return {'success': true, 'message': 'ভিডিও সফলভাবে পাবলিশ হয়েছে!'};
      }
    } catch (e) {
      _isUploading = false;
      notifyListeners();
      return {
        'success': false,
        'message': 'কমিউনিটি স্ট্যান্ডার্ড ভঙ্গের কারণে ভিডিওটি রিজেক্ট হয়েছে বা নেটওয়ার্ক সমস্যা!',
      };
    }

    _isUploading = false;
    notifyListeners();
    return {'success': false, 'message': 'আপলোড ব্যর্থ হয়েছে!'};
  }

  // ২৪ ঘণ্টার স্টোরিজ আপলোড
  Future<bool> publishStory(File mediaFile) async {
    _isUploading = true;
    _uploadProgress = 0.0;
    _statusMessage = 'স্টোরি আপলোড হচ্ছে...';
    notifyListeners();

    try {
      final fileUrl = await _b2Service.uploadMediaDirectToB2(mediaFile);
      if (fileUrl != null) {
        final response = await _apiService.post(
          ApiConstants.stories,
          data: {'media_url': fileUrl, 'media_type': 'video'},
        );
        _isUploading = false;
        notifyListeners();
        return response.statusCode == 201;
      }
    } catch (_) {}

    _isUploading = false;
    notifyListeners();
    return false;
  }
}