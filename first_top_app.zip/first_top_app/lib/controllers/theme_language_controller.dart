import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeLanguageController with ChangeNotifier {
  bool _isDarkMode = true;
  String _currentLanguage = 'bn'; // 'bn' = বাংলা, 'en' = English
  bool _isDataSaverOn = false;

  bool get isDarkMode => _isDarkMode;
  String get currentLanguage => _currentLanguage;
  bool get isDataSaverOn => _isDataSaverOn;

  ThemeLanguageController() {
    _loadPreferences();
  }

  // সংরক্ষিত সেটিংস লোড করা
  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    _isDarkMode = prefs.getBool('is_dark_mode') ?? true;
    _currentLanguage = prefs.getString('language') ?? 'bn';
    _isDataSaverOn = prefs.getBool('data_saver') ?? false;
    notifyListeners();
  }

  // থিম পরিবর্তন (Dark / Light)
  Future<void> toggleTheme(bool isDark) async {
    _isDarkMode = isDark;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_dark_mode', isDark);
  }

  // ভাষা পরিবর্তন (বাংলা / English)
  Future<void> setLanguage(String langCode) async {
    _currentLanguage = langCode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', langCode);
  }

  // ডাটা সেভার টগল
  Future<void> toggleDataSaver(bool isOn) async {
    _isDataSaverOn = isOn;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('data_saver', isOn);
  }
}