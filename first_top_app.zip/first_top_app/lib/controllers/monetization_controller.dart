import 'package:flutter/material.dart';
import '../config/api_constants.dart';
import '../services/api_service.dart';

class MonetizationController with ChangeNotifier {
  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  Map<String, dynamic>? _eligibility;
  Map<String, dynamic>? _analytics;

  bool get isLoading => _isLoading;
  Map<String, dynamic>? get eligibility => _eligibility;
  Map<String, dynamic>? get analytics => _analytics;

  // মনিটাইজেশন যোগ্যতা যাচাই
  Future<void> checkEligibility() async {
    _isLoading = true;
    notifyListeners();

    try {
      final res = await _apiService.get(ApiConstants.checkEligibility);
      if (res.statusCode == 200 && res.data['success']) {
        _eligibility = res.data['data'];
      }
    } catch (e) {
      debugPrint('[Eligibility Error]: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  // ক্রিয়েটর স্টুডিও অ্যানালিটিক্স লোড
  Future<void> fetchCreatorDashboard() async {
    _isLoading = true;
    notifyListeners();

    try {
      final res = await _apiService.get(ApiConstants.creatorDashboard);
      if (res.statusCode == 200 && res.data['success']) {
        _analytics = res.data['data'];
      }
    } catch (e) {
      debugPrint('[Creator Dashboard Error]: $e');
    }

    _isLoading = false;
    notifyListeners();
  }
}