import 'package:flutter/foundation.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../config/api_constants.dart';

class SocketService {
  IO.Socket? _socket;

  IO.Socket? get socket => _socket;

  // সকেট কানেকশন ইনিশিয়ালাইজেশন
  void initSocket(String jwtToken) {
    if (_socket != null && _socket!.connected) return;

    _socket = IO.io(
      ApiConstants.socketUrl,
      IO.OptionBuilder()
          .setTransports(['websocket'])
          .disableAutoConnect()
          .setAuth({'token': jwtToken})
          .build(),
    );

    _socket!.connect();

    _socket!.onConnect((_) {
      debugPrint('[Socket.io] Connected to Render Server successfully!');
    });

    _socket!.onDisconnect((_) {
      debugPrint('[Socket.io] Disconnected from server!');
    });

    _socket!.onConnectError((err) {
      debugPrint('[Socket.io Error]: $err');
    });
  }

  // মেসেজ পাঠানো
  void sendMessage({required String receiverId, required String text, String mediaUrl = ''}) {
    _socket?.emit('send_message', {
      'receiverId': receiverId,
      'text': text,
      'media_url': mediaUrl,
    });
  }

  // মেসেজ দেখা শেষ হলে Seen সিগন্যাল পাঠানো
  void markAsSeen(String senderId) {
    _socket?.emit('mark_as_seen', {'senderId': senderId});
  }

  // টাইপিং ইন্ডিকেটর পাঠানো
  void emitTyping({required String receiverId, required bool isTyping}) {
    _socket?.emit('typing', {
      'receiverId': receiverId,
      'isTyping': isTyping,
    });
  }

  void disconnect() {
    _socket?.disconnect();
    _socket = null;
  }
}