import 'dart:io';
import 'package:dio/dio.dart';
import '../config/api_constants.dart';
import 'api_service.dart';

class B2UploadService {
  final ApiService _apiService = ApiService();
  final Dio _uploadDio = Dio();

  // ব্যাকব্লেজে সরাসরি বাইনারি স্ট্রিম আকারে আপলোড
  Future<String?> uploadMediaDirectToB2(
    File file, {
    Function(int sent, int total)? onProgress,
  }) async {
    try {
      final fileName = file.path.split('/').last;
      const fileType = 'video/mp4';

      // ধাপ ১: Render ব্যাক-এন্ড থেকে Presigned Upload URL নেওয়া
      final presignedResponse = await _apiService.post(
        ApiConstants.presignedUrl,
        data: {'fileName': fileName, 'fileType': fileType},
      );

      if (presignedResponse.statusCode != 200 || !presignedResponse.data['success']) {
        throw Exception('Presigned URL পাওয়া যায়নি!');
      }

      final uploadUrl = presignedResponse.data['data']['uploadUrl'];
      final fileUrl = presignedResponse.data['data']['fileUrl'];

      // ধাপ ২: সরাসরি Backblaze B2-তে HTTP PUT রিকোয়েস্ট পাঠানো
      final fileLength = await file.length();
      final fileStream = file.openRead();

      final response = await _uploadDio.put(
        uploadUrl,
        data: fileStream,
        options: Options(
          headers: {
            'Content-Type': fileType,
            'Content-Length': fileLength,
          },
        ),
        onSendProgress: onProgress,
      );

      if (response.statusCode == 200) {
        return fileUrl;
      }
    } catch (e) {
      print('[B2 Upload Error]: $e');
    }
    return null;
  }
}