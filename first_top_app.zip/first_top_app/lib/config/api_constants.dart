class ApiConstants {
  // আপনার Render লাইভ ব্যাক-এন্ড URL
  static const String baseUrl = 'https://first-top-backend.onrender.com/api';
  static const String socketUrl = 'https://first-top-backend.onrender.com';

  // Auth Endpoints
  static const String register = '$baseUrl/auth/register';
  static const String login = '$baseUrl/auth/login';
  static const String getMe = '$baseUrl/auth/me';

  // Core Features
  static const String settings = '$baseUrl/settings';
  static const String feed = '$baseUrl/videos/feed';
  static const String viewDuration = '$baseUrl/videos'; // /:id/view
  static const String presignedUrl = '$baseUrl/videos/presigned-url';
  static const String publishVideo = '$baseUrl/videos/publish';
  static const String stories = '$baseUrl/videos/stories';

  // Chat & Wallet
  static const String chatHistory = '$baseUrl/chats';
  static const String sendGift = '$baseUrl/wallet/send-gift';
  static const String depositRequest = '$baseUrl/wallet/deposit-request';
  static const String myTransactions = '$baseUrl/wallet/my-transactions';

  // Monetization
  static const String checkEligibility = '$baseUrl/monetization/check-eligibility';
  static const String adImpression = '$baseUrl/monetization/ad-impression';
  static const String creatorDashboard = '$baseUrl/monetization/creator-dashboard';
}